package com.example.recycleview;

public class ListItem {

    private String head;
    private String Decs;

    public ListItem(String head, String decs) {
        this.head = head;
        Decs = decs;
    }

    public String getHead() {
        return head;
    }

    public String getDecs() {
        return Decs;
    }
}
