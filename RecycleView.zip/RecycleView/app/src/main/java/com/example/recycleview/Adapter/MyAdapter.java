package com.example.recycleview.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recycleview.ListItem;
import com.example.recycleview.R;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private List<ListItem> list_items;
    private Context context;

    public MyAdapter(List<ListItem> list_items, Context context) {
        this.list_items = list_items;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(parent.getContext())
               .inflate(R.layout.list_items,parent,false);

       return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final ListItem list_it =  list_items.get(position);
        holder.txthead.setText( list_it.getHead());
        holder.txtDesc.setText( list_it.getDecs());
        String Pos = String.valueOf(position);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "You Click On CardView Item Number"+list_it.getHead(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list_items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView txthead,txtDesc;
        public LinearLayout linearLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txthead=(TextView)itemView.findViewById(R.id.txthead);
            txtDesc=(TextView)itemView.findViewById(R.id.txtdesc);
            linearLayout=(LinearLayout) itemView.findViewById(R.id.LinearLayout );

        }
    }
}
